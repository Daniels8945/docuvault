--
-- PostgreSQL database dump
--

\restrict AuoAp7oUx4t7MYzEkzO4MabWIpLU8za0xCNPCVwW7btG7DSWbB7mXrdaGdJY03b

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.approval (
    document_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    status character varying NOT NULL,
    notes character varying,
    id character varying NOT NULL,
    reviewers json NOT NULL,
    submitted_at timestamp without time zone NOT NULL,
    reviewed_by character varying,
    reviewed_at timestamp without time zone
);


ALTER TABLE public.approval OWNER TO docuvault;

--
-- Name: document; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.document (
    name character varying NOT NULL,
    file_type character varying NOT NULL,
    file_size integer NOT NULL,
    workspace_id character varying NOT NULL,
    folder_id character varying,
    status character varying NOT NULL,
    uploaded_by character varying NOT NULL,
    id character varying NOT NULL,
    file_path character varying NOT NULL,
    tags json,
    current_version integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.document OWNER TO docuvault;

--
-- Name: documentversion; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.documentversion (
    document_id character varying NOT NULL,
    version_number integer NOT NULL,
    file_path character varying NOT NULL,
    uploaded_by character varying NOT NULL,
    notes character varying,
    id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.documentversion OWNER TO docuvault;

--
-- Name: folder; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.folder (
    name character varying NOT NULL,
    workspace_id character varying NOT NULL,
    parent_folder_id character varying,
    id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.folder OWNER TO docuvault;

--
-- Name: organization; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.organization (
    name character varying NOT NULL,
    description character varying,
    id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organization OWNER TO docuvault;

--
-- Name: user; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public."user" (
    name character varying NOT NULL,
    email character varying NOT NULL,
    role character varying NOT NULL,
    id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public."user" OWNER TO docuvault;

--
-- Name: whatsappgrouprule; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.whatsappgrouprule (
    id character varying NOT NULL,
    group_jid character varying NOT NULL,
    group_name character varying NOT NULL,
    workspace_id character varying NOT NULL,
    folder_id character varying,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.whatsappgrouprule OWNER TO docuvault;

--
-- Name: workspace; Type: TABLE; Schema: public; Owner: docuvault
--

CREATE TABLE public.workspace (
    name character varying NOT NULL,
    description character varying,
    organization_id character varying NOT NULL,
    id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.workspace OWNER TO docuvault;

--
-- Data for Name: approval; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.approval (document_id, submitted_by, status, notes, id, reviewers, submitted_at, reviewed_by, reviewed_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.document (name, file_type, file_size, workspace_id, folder_id, status, uploaded_by, id, file_path, tags, current_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documentversion; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.documentversion (document_id, version_number, file_path, uploaded_by, notes, id, created_at) FROM stdin;
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.folder (name, workspace_id, parent_folder_id, id, created_at) FROM stdin;
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.organization (name, description, id, created_at) FROM stdin;
Onction	\N	org_5dd362d4	2026-07-24 22:25:20.362023
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public."user" (name, email, role, id, created_at) FROM stdin;
Olaoluwa	olaoluwa@onction.com	admin	user_olaoluwa	2026-06-03 14:39:36.200688
\.


--
-- Data for Name: whatsappgrouprule; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.whatsappgrouprule (id, group_jid, group_name, workspace_id, folder_id, created_at) FROM stdin;
\.


--
-- Data for Name: workspace; Type: TABLE DATA; Schema: public; Owner: docuvault
--

COPY public.workspace (name, description, organization_id, id, created_at) FROM stdin;
Tech Docs	\N	org_5dd362d4	ws_344109ff	2026-07-24 22:25:46.194177
\.


--
-- Name: approval approval_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.approval
    ADD CONSTRAINT approval_pkey PRIMARY KEY (id);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (id);


--
-- Name: documentversion documentversion_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.documentversion
    ADD CONSTRAINT documentversion_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: whatsappgrouprule whatsappgrouprule_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.whatsappgrouprule
    ADD CONSTRAINT whatsappgrouprule_pkey PRIMARY KEY (id);


--
-- Name: workspace workspace_pkey; Type: CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.workspace
    ADD CONSTRAINT workspace_pkey PRIMARY KEY (id);


--
-- Name: ix_document_name; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE INDEX ix_document_name ON public.document USING btree (name);


--
-- Name: ix_folder_name; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE INDEX ix_folder_name ON public.folder USING btree (name);


--
-- Name: ix_organization_name; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE INDEX ix_organization_name ON public.organization USING btree (name);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- Name: ix_whatsappgrouprule_group_jid; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE INDEX ix_whatsappgrouprule_group_jid ON public.whatsappgrouprule USING btree (group_jid);


--
-- Name: ix_workspace_name; Type: INDEX; Schema: public; Owner: docuvault
--

CREATE INDEX ix_workspace_name ON public.workspace USING btree (name);


--
-- Name: approval approval_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.approval
    ADD CONSTRAINT approval_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: document document_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folder(id);


--
-- Name: document document_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace(id);


--
-- Name: documentversion documentversion_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.documentversion
    ADD CONSTRAINT documentversion_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: folder folder_parent_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_parent_folder_id_fkey FOREIGN KEY (parent_folder_id) REFERENCES public.folder(id);


--
-- Name: folder folder_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace(id);


--
-- Name: whatsappgrouprule whatsappgrouprule_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.whatsappgrouprule
    ADD CONSTRAINT whatsappgrouprule_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folder(id);


--
-- Name: whatsappgrouprule whatsappgrouprule_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.whatsappgrouprule
    ADD CONSTRAINT whatsappgrouprule_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspace(id);


--
-- Name: workspace workspace_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docuvault
--

ALTER TABLE ONLY public.workspace
    ADD CONSTRAINT workspace_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- PostgreSQL database dump complete
--

\unrestrict AuoAp7oUx4t7MYzEkzO4MabWIpLU8za0xCNPCVwW7btG7DSWbB7mXrdaGdJY03b

